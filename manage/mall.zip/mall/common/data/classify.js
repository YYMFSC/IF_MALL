var data = {
    tabs: [{
        text: '推荐商品',
        value: 'tj'
    }, {
        text: '生鲜食品',
        value: 'sx'
    }, {
        text: '粮油/速食',
        value: 'ly'
    }, {
        text: '零食酒水',
        value: 'ls'
    }, {
        text: '母婴天地',
        value: 'my'
    }, {
        text: '家庭清洁',
        value: 'jt'
    }]
}
module.exports = data;