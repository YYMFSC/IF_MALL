var config;

config = {
  IF_Url: 'http://localhost:58843/manage/IO.ashx',
  App_Name:'电子商城'
}

module.exports = config;