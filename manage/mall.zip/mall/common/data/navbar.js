var data = {
    tabs: [{
        text: '首页',
        className: 'home',
        view: 'home',
        url: '/pages/home/home'
    }, {
        text: '分类',
        className: 'sort',
        view: 'sort',
        url: '/pages/sort/sort'
    }, {
        text: '购物车',
        className: 'cart',
        view: 'cart',
        url: '/pages/cart/cart'
    }, {
        text: '我的',
        className: 'mine',
        view: 'mine',
        url: '/pages/mine/mine'
    }]
}
module.exports = data;